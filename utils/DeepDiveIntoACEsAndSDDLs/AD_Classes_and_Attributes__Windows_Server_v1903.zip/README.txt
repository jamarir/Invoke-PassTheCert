https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-ada2/53ac3882-2fb1-4184-a6cf-a749874fae88
https://www.microsoft.com/en-us/download/details.aspx?id=23782